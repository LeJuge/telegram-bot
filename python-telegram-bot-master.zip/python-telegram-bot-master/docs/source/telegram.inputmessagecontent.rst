telegram.InputMessageContent
============================

.. autoclass:: telegram.InputMessageContent
    :members:
    :show-inheritance:
