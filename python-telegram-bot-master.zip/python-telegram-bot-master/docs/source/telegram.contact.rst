telegram.Contact
================

.. autoclass:: telegram.Contact
    :members:
    :show-inheritance:
