telegram.Audio
==============

.. autoclass:: telegram.Audio
    :members:
    :show-inheritance:
