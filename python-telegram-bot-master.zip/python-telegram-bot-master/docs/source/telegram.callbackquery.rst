telegram.CallbackQuery
======================

.. autoclass:: telegram.CallbackQuery
    :members:
    :show-inheritance:
