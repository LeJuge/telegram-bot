telegram.File
=============

.. autoclass:: telegram.File
    :members:
    :show-inheritance:
