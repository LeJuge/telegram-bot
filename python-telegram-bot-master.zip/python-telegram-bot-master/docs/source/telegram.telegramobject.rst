telegram.TelegramObject
=======================

.. autoclass:: telegram.TelegramObject
    :members:
    :show-inheritance:
