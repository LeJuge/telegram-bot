telegram.InlineQueryResultContact
=================================

.. autoclass:: telegram.InlineQueryResultContact
    :members:
    :show-inheritance:
