telegram.InlineQueryResultCachedDocument
========================================

.. autoclass:: telegram.InlineQueryResultCachedDocument
    :members:
    :show-inheritance:
