telegram.InlineQueryResultCachedMpeg4Gif
========================================

.. autoclass:: telegram.InlineQueryResultCachedMpeg4Gif
    :members:
    :show-inheritance:
