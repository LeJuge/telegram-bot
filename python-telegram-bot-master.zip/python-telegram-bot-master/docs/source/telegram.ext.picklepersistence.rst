telegram.ext.PicklePersistence
==============================

.. autoclass:: telegram.ext.PicklePersistence
    :members:
    :show-inheritance:
