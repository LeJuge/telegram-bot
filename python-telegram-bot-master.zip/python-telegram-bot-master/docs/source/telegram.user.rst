telegram.User
=============

.. autoclass:: telegram.User
    :members:
    :undoc-members:
    :show-inheritance:
