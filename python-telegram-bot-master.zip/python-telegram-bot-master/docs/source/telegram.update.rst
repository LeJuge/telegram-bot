telegram.Update
===============

.. autoclass:: telegram.Update
    :members:
    :undoc-members:
    :show-inheritance:
