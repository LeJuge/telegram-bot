telegram.InputMedia
===================

.. autoclass:: telegram.InputMedia
    :members:
    :show-inheritance:
